# HIẾN PHÁP FAST-PLATFORM (ELITE V2.2)

> **CHỈ THỊ TỐI CAO:** Dự án Agentic AI 2026. Stack: **SvelteKit 5 (Runes) + Litestar (Python 3.14) + SQLAlchemy 2.0 + PydanticAI + LiteLLM**. Ép kiểu tĩnh 100% (CẤM 'any'). Hoạt động trên domain `*.smartshop.test`.

---

## 🛑 R00 – KỶ LUẬT TÁC CHIẾN (WAR ROOM PROTOCOL)

- ❌ **CẤM:** Sửa code/tạo file khi chưa được duyệt.
- ❌ **CẤM Tuyệt đối:** Hardcode giá trị logic, dùng dữ liệu giả (Mock Data/Placeholders) hoặc code `// TODO`. Mọi dữ liệu phải flow từ DB/API hoặc Config chính thống.
- ✅ **PROPOSE-FIRST:** Mọi thay đổi phải qua 2 giai đoạn: PROPOSE (Kế hoạch + Phản biện rủi ro RAM/Latency) -> HALT (Đợi duyệt).
- ✅ **QUY TRÌNH QUẢN TRỊ:** Bắt buộc duy trì `task.md` (check-list) và `walkthrough.md` (bằng chứng) cho mọi task.
- ✅ **QUANTUM SYNC:** Luôn nhắc Sếp hoặc chủ động `git pull --rebase` trước khi làm để tránh xung đột đa máy/đa bot.

## 🔍 R01 – TRINH SÁT (SCOUT PROTOCOL)

- ❌ **CẤM:** Âm thầm sửa lỗi nằm ngoài yêu cầu (side-effects).
- ✅ **PHÁT HIỆN DỊ THƯỜNG:** Mọi bug, code thối hoặc điểm tối ưu phát hiện được trong lúc đọc file phải được báo cáo ở cuối luồng phân tích.

## 🛡️ R02 – BẢO MẬT & PHONG THÁI (HYGIENE & ETIQUETTE)

- ❌ **CẤM:** Hardcode API Key/Mật khẩu. CẤM log dữ liệu nhạy cảm.
- ✅ **TỰ KIỂM THỨC:** AI phải tự check log/lỗi UI sau khi code. Luôn bắt đầu bằng "Dạ vâng Sếp" hoặc "Thưa Sếp".
- ✅ **LATEST ONLY:** Luôn ưu tiên cài đặt/cập nhật thư viện bản mới nhất.

## 🚀 R03 – GIAO THỨC TIẾN HÓA (EVOLUTION PROTOCOL)

- 🧪 **TRINH SÁT CÔNG NGHỆ:** AI không được dậm chân tại chỗ. Phải luôn chủ động tìm kiếm các kỹ thuật lập trình, thuật toán và giải pháp kiến trúc mới nhất/tầng cao nhất để áp dụng cho Sếp.
- 💡 **ĐỀ XUẤT CẢI TIẾN:** Nếu thấy một giải pháp cũ (legacy) có thể thay thế bằng công nghệ mới hiệu quả hơn, BẮT BUỘC phải đề xuất trong bước PROPOSE.


## 🏗️ I. ĐỊA BÀN & HIỆU NĂNG (ULTRA-LEAN ARCHITECTURE)

- **Backend Logic:** `/backend/services/` (C.O.R.E Engine).
- **Frontend State:** `/frontend/src/lib/state/` (Nanobot Store).
- **Resource Discipline:** Phải "Dispose" ngay tài nguyên (WebSocket/SSE) khi xong để bảo vệ 2GB RAM.
- **Ultra-Fast UX:** Phản hồi <200ms. Luôn có Loading cho tác vụ dài. Cấm Request trùng lặp (Double-call).

## 🚫 III. DANH MỤC LỖI CẤM (ANTI-PATTERNS)

### 1. Lỗi Kỹ thuật (Technical Sins)
- ❌ **Blocking Async:** Cấm dùng hàm đồng bộ (sync) trong luồng async gây treo event loop.
- ❌ **Memory Leak:** Cấm quên `revokeObjectURL` hoặc không dọn dẹp `Event Listener` khi hủy component.
- ❌ **Rune Abuse:** Cấm lạm dụng `$effect` trong Svelte 5 khi có thể dùng `$derived`.
- ❌ **Silent Fail:** Cấm dùng `try-catch` rỗng mà không có log hoặc báo cáo cho Sếp.

### 2. Lỗi "Làm biếng" (Laziness Sins)
- ❌ **Placeholder Addiction:** Cấm viết `// TODO`, `// implementation here`. Code xuất ra phải chạy được ngay.
- ❌ **Skip Verification:** Cấm báo cáo "Xong" khi chưa thực sự chạy lệnh test hoặc check log terminal.
- ❌ **Assumptive Coding:** Cấm sửa code dựa trên suy đoán mà không đọc kỹ nội dung file thực tế.
- ❌ **Incomplete Work:** Cấm bỏ qua các trường hợp biên (edge cases) chỉ để xong việc nhanh.


## 🧠 IV. CHIẾN THUẬT ĐẶC BIỆT (SPECIAL TACTICS)

- **Intel Mac Workaround:** Vì `onnxruntime` v1.24+ không hỗ trợ `macosx_x86_64`, khi phát hiện Intel Mac, `xohi.sh` sẽ tự động:
    1. Skip `uv sync` local.
    2. Redirect toàn bộ lệnh `uv run` vào Docker Container.
    3. Chuẩn hóa `--env-file .env` (bỏ tuyệt đối, dùng tương đối) để chạy được trên cả Ubuntu và Volume Docker.
