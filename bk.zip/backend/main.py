import os
import logging
import warnings
from dotenv import load_dotenv

# Suppress library warnings
warnings.filterwarnings("ignore", message=".*Pydantic V1 functionality isn't compatible.*")
warnings.filterwarnings("ignore", message=".*now uses mean pooling instead of CLS embedding.*")
warnings.filterwarnings("ignore", category=UserWarning, module="pydantic_ai")

from litestar import Litestar
from litestar.config.cors import CORSConfig
from litestar.openapi import OpenAPIConfig
from litestar.openapi.spec import Components
from litestar.stores.memory import MemoryStore
from litestar.middleware.rate_limit import RateLimitConfig

# Handlers and Plugins
from backend.exceptions import global_exception_handler
from backend.lifespan import lifespan
from backend.database import alchemy_config
from advanced_alchemy.extensions.litestar import SQLAlchemyPlugin

# Route Handlers
from backend.routers.intent import IntentController
from backend.routers.intent_stream import IntentStreamController
from backend.routers.pulse_stream import PulseStreamController
from backend.controllers.health import HealthController
from backend.routers.mcp.router import MCPController
from backend.controllers.auth import AuthController
from backend.controllers.auth_extended import AuthExtendedController
from backend.controllers.notifications import NotificationController
from backend.controllers.auditor import AuditorController
from backend.controllers.user import UserController
from backend.controllers.category import CategoryController
from backend.controllers.product import ProductController
from backend.controllers.article import ArticleController
from backend.controllers.order import OrderController
from backend.controllers.settings import SettingsController
from backend.controllers.ai_management import AIController
from backend.controllers.chat import ChatController
from backend.routers.content_router import ContentController
from backend.routers.content_stream import ContentStreamController
from backend.routers.voice_stream import stt_websocket
from backend.controllers.tts_handler import TTSController
from backend.middleware import AuthMiddleware
from backend.body_limit import BodyLimitMiddleware

load_dotenv(".env")

# R72: Unified Model Environment Sync
for key in ["GOOGLE_API_KEY", "GOOGLE_API_KEY_1", "GOOGLE_API_KEY_2"]:
    os.environ.pop(key, None)

alchemy_plugin = SQLAlchemyPlugin(config=alchemy_config.litestar_config)
import backend.mcp.tools 

logger = logging.getLogger("api-gateway")

# CORS configs (Rule R4: Zero-Trust)
allowed_origins = [
    os.getenv("ADMIN_URL", "https://admin.smartshop.test"),
    os.getenv("API_URL", "https://api.smartshop.test"),
    os.getenv("APP_URL", "https://smartshop.test")
]
cors_origins_str = os.getenv("BACKEND_CORS_ORIGINS")
if cors_origins_str:
    allowed_origins = [o.strip() for o in cors_origins_str.split(",")]

cors_config = CORSConfig(allow_origins=allowed_origins, allow_credentials=True)

# Application Instance
memory_store = MemoryStore()
rate_limit_config = RateLimitConfig(
    rate_limit=("minute", int(os.getenv("RATE_LIMIT_GLOBAL_MINUTE", "1000"))),
    exclude=["/health", "/metrics", "/schema"],
    store="memory_store"
)

app = Litestar(
    route_handlers=[
        IntentController, IntentStreamController, PulseStreamController,
        HealthController, MCPController, AuthController, AuthExtendedController,
        NotificationController, AuditorController, UserController,
        CategoryController, ProductController, ArticleController, OrderController,
        ChatController, SettingsController, AIController, ContentController, ContentStreamController, stt_websocket, TTSController,
    ],
    middleware=[BodyLimitMiddleware, rate_limit_config.middleware, AuthMiddleware],
    cors_config=cors_config,
    stores={"memory_store": memory_store},
    openapi_config=OpenAPIConfig(
        title="Fast Platform API Gateway", 
        version="1.0.0",
        components=Components()
    ),
    exception_handlers={Exception: global_exception_handler},
    lifespan=[lifespan],
    plugins=[alchemy_plugin]
)
